
Developer: Muhammad Junaid Raza
Email: razajunaid@hotmail.com

    Excellent code for beginners learning TCP/IP based
    communication.

    This program consists of 2 versions, client and server.
    server must be running on remote machine, dont worry it will be invisible or just
    put it in startup directory of start menu.

    then just run the client at any machine give the IP or host name
    of the remote machine where that server is running and just press any of command
    you can put as many commands as u like, i just tried to give some idea.
    be carefull about the shutdown command as it will force all apps on remote machine 2 close.

    
   later i will send its better version containing many commands and server will automatically 
   start whenever windows starts.

   keep in mind that most of commands like calc, and notepad will work only in windows 98.
for winnt, just add a bit extra code to find whether running winnt/2000/xp or 98/95.

NOW 2 MORE FEATURES ADDED.

1: the server app running on client machine can't found in Ctrl+Alt+Del list of processes.

2: u can find the current internet explorer address of the client machine by just pressing the net check button.

	AND A LOT LOT OF COMMANDS TO PLAY.


   i could also send some kind of chat app, but there r a lot discussing chat, but u can also convert it into a chat app.

      Do mail me for any comments n suggestions.
      razajunaid@hotmail.com

(ITS UPDATED FULLY ADVANCE VERSION WILL BE AVAILABLE SOON WITH ADVANCE OPTIONS).

     the software is freeware and can be used and converted as required (but dont forget for due credits).